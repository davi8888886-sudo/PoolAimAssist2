# POOL AIM ASSIST 2.0 (Android)

Assistente visual de mira para sinuca. Kotlin puro, sem dependências no app, processamento 100% local.
**Não faz tacadas por você** — ele só desenha linhas; a jogada é sempre sua.

## Como compilar o APK (sem PC)
**Opção A – GitHub Actions (mais simples)**
1. Crie um repositório no GitHub e envie o conteúdo desta pasta (`PoolAimAssist`) para a branch `main`.
2. Aba **Actions** → workflow *Build APK* → aguarde (~5 min).
3. Baixe o artefato **PoolAimAssist-2.0-debug-apk** (`app-debug.apk`).
   O artefato **test-reports** traz o resultado dos testes unitários.

**Opção B – AndroidIDE (no celular)**: abra a pasta, aguarde o Gradle sincronizar (precisa de internet na 1ª vez),
*Build → Assemble Debug*. APK em `app/build/outputs/apk/debug/`.

## Instalar
1. Copie o `app-debug.apk` para o Galaxy M23 e toque nele (permita "instalar apps desconhecidos").
2. Se já tiver a versão 1.0 com a mesma assinatura de debug, ela é atualizada; senão desinstale a antiga antes.

## Primeiro uso
1. Abra o app → **Iniciar assistente** → permita *Exibir sobre outros apps*, notificações e a captura de tela.
2. Toque na bolha flutuante para abrir o **painel**:
   - **Analisar** – captura 1 quadro, detecta mesa/bolas e desenha as linhas.
   - **Linhas** – mostra/oculta todas as linhas.
   - **Auto** – reanalisa sozinho a cada 1–2,5 s (as camadas somem por ~0,2 s a cada captura, então há um piscar rápido).
   - **Mira** – você arrasta na tela e vê: tabelas (até 2), 1ª bola atingida, direção da bola atingida, desvio da branca. Desligue para jogar.
   - **Calibrar** – ajuste o retângulo sobre o feltro (cantos nas bordas internas, onde ficam as caçapas) e toque **Salvar mesa**.
   - **Fechar** – encerra o assistente.
3. Configurações (no app): cores, espessura e intensidade das linhas, intervalo do Auto, grupo de bolas, sensibilidade.

## Legenda das linhas (cores padrão, configuráveis)
Verde = trajetória da branca · Amarelo = bola atingida → caçapa · Azul tracejado = branca após o impacto ·
Rosa = mira manual · Círculo branco = posição da branca no impacto · Ponto laranja = ponto de contato.
Toda linha tem contorno escuro para contraste.

## Limitações conhecidas
- **Não foi compilado nem testado em aparelho real por quem escreveu esta versão** (ver RELATORIO.md).
- Sem efeito (spin), atrito ou potência. Perspectiva inclinada/zoom não é corrigida.
- Os limiares de cor podem exigir ajuste (use Calibrar e "Mostrar bolas detectadas").
