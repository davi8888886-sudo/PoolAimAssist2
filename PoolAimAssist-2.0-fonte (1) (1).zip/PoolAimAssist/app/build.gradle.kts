plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.poolaimassist"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.poolaimassist"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// Sem dependências no app: apenas o SDK do Android + Kotlin stdlib. JUnit só para testes unitários.
dependencies {
    testImplementation("junit:junit:4.13.2")
}
