package com.poolaimassist

import android.graphics.Bitmap

object Analyzer {
    fun run(src: Bitmap, p: Prefs): AnalysisResult {
        val sw = src.width
        val sh = src.height
        val scale = minOf(1f, 800f / maxOf(sw, sh))
        val pw = (sw * scale).toInt().coerceAtLeast(1)
        val ph = (sh * scale).toInt().coerceAtLeast(1)
        val bmp = if (scale < 1f) Bitmap.createScaledBitmap(src, pw, ph, true) else src
        val px = IntArray(pw * ph)
        bmp.getPixels(px, 0, pw, 0, 0, pw, ph)
        if (bmp !== src) bmp.recycle()

        fun fail(msg: String) = AnalysisResult(pw, ph, sw, sh, null, emptyList(), emptyList(), 0f, emptyList(), msg)

        val hsv = Vision.toHsv(px)
        val manual = p.getManualTable()
        val felt: Vision.Felt = if (manual != null) {
            Vision.manualFelt(pw, ph, px, manual)
        } else {
            Vision.findTable(pw, ph, px, hsv, p.feltMode)
                ?: return fail("Mesa não encontrada. Toque em Calibrar e ajuste o retângulo sobre o feltro.")
        }
        val table = felt.table
        val pockets = Planner.pockets(table)
        val det = Vision.detectBalls(pw, ph, px, hsv, felt, p.sensitivity, pockets)
            ?: return AnalysisResult(pw, ph, sw, sh, table, pockets, emptyList(), 0f, emptyList(),
                "Nenhuma bola detectada. Reajuste a calibração ou aumente a sensibilidade.")
        val (balls, r) = det
        if (balls.none { it.type == BallType.CUE })
            return AnalysisResult(pw, ph, sw, sh, table, pockets, balls, r, emptyList(), "Bola branca não encontrada.")

        val shots = Planner.plan(table, balls, r, p.group, p.alternatives)
        val msg = when {
            !table.fullView && pockets.isEmpty() -> "Visão aproximada: nenhuma caçapa visível. Use a visão superior."
            shots.isEmpty() -> "Nenhuma jogada livre encontrada (bolas bloqueando ou ângulo fechado)."
            !table.fullView -> "Visão aproximada: bordas/caçapas fora da tela foram ignoradas (menos precisão)."
            else -> null
        }
        return AnalysisResult(pw, ph, sw, sh, table, pockets, balls, r, shots, msg)
    }
}
