package com.poolaimassist

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Física de colisão (bolas idênticas, sem atrito/efeito):
 *  - Bola fantasma G = alvo - dir(alvo->caçapa) * 2r: onde a branca deve estar no impacto.
 *  - Direção da bola-alvo = linha de centros (G -> alvo).
 *  - Após o impacto a branca segue a tangente: a - (a·b) b.
 *  - Tabelas: reflexão da bola fantasma na borda (método do espelho).
 */
object Planner {

    fun pockets(t: Table): List<Pocket> {
        val s = 0.7071f
        val cx = (t.left + t.right) / 2f
        val cy = (t.top + t.bottom) / 2f
        val l = ArrayList<Pocket>()
        if (t.leftReal && t.topReal) l += Pocket(V(t.left, t.top), V(-s, -s), 0.42f)
        if (t.rightReal && t.topReal) l += Pocket(V(t.right, t.top), V(s, -s), 0.42f)
        if (t.leftReal && t.bottomReal) l += Pocket(V(t.left, t.bottom), V(-s, s), 0.42f)
        if (t.rightReal && t.bottomReal) l += Pocket(V(t.right, t.bottom), V(s, s), 0.42f)
        if ((t.right - t.left) >= (t.bottom - t.top)) {
            if (t.topReal && t.leftReal && t.rightReal) l += Pocket(V(cx, t.top), V(0f, -1f), 0.5f)
            if (t.bottomReal && t.leftReal && t.rightReal) l += Pocket(V(cx, t.bottom), V(0f, 1f), 0.5f)
        } else {
            if (t.leftReal && t.topReal && t.bottomReal) l += Pocket(V(t.left, cy), V(-1f, 0f), 0.5f)
            if (t.rightReal && t.topReal && t.bottomReal) l += Pocket(V(t.right, cy), V(1f, 0f), 0.5f)
        }
        return l
    }

    fun segDist(p: V, a: V, b: V): Float {
        val ab = b - a
        val l2 = ab.dot(ab)
        if (l2 < 1e-6f) return (p - a).len()
        val t = ((p - a).dot(ab) / l2).coerceIn(0f, 1f)
        return (p - (a + ab * t)).len()
    }

    private fun clear(a: V, b: V, obs: List<Ball>, minD: Float) = obs.all { segDist(it.c, a, b) >= minD }

    private fun insideCenters(g: V, t: Table, r: Float): Boolean {
        val m = 0.8f * r
        if (t.leftReal && g.x < t.left + m) return false
        if (t.rightReal && g.x > t.right - m) return false
        if (t.topReal && g.y < t.top + m) return false
        if (t.bottomReal && g.y > t.bottom - m) return false
        return true
    }

    private fun bounce(c: V, g: V, vertical: Boolean, w: Float, t: Table, r: Float): V? {
        val gr = if (vertical) V(2f * w - g.x, g.y) else V(g.x, 2f * w - g.y)
        val den = if (vertical) gr.x - c.x else gr.y - c.y
        if (abs(den) < 1e-4f) return null
        val tt = (w - (if (vertical) c.x else c.y)) / den
        if (tt <= 0.02f || tt >= 0.98f) return null
        val bp = V(c.x + (gr.x - c.x) * tt, c.y + (gr.y - c.y) * tt)
        val ok = if (vertical) bp.y > t.top + r && bp.y < t.bottom - r
        else bp.x > t.left + r && bp.x < t.right - r
        return if (ok) bp else null
    }

    private fun rayToBounds(g: V, u: V, t: Table, r: Float): Float {
        var best = 1e9f
        if (u.x > 1e-4f) best = min(best, (t.right - r - g.x) / u.x)
        else if (u.x < -1e-4f) best = min(best, (t.left + r - g.x) / u.x)
        if (u.y > 1e-4f) best = min(best, (t.bottom - r - g.y) / u.y)
        else if (u.y < -1e-4f) best = min(best, (t.top + r - g.y) / u.y)
        return max(best, 0f)
    }

    private fun make(
        tb: Ball, pk: Pocket, path: List<V>, ghost: V, a: V, dir: V, cosCut: Float,
        pathLen: Float, dTP: Float, bank: Boolean, t: Table, r: Float
    ): Shot {
        val L = t.longSide
        val cut = Math.toDegrees(acos(cosCut.coerceIn(-1f, 1f)).toDouble()).toFloat()
        var p = 0.92f * exp(-(1.4f * pathLen / L + 2.0f * dTP / L)) * (1f - 0.6f * (cut / 90f).pow(1.5f))
        if (bank) p *= 0.45f
        p = p.coerceIn(0.02f, 0.85f)
        val tang = a - dir * cosCut
        val tl = tang.len()
        val after = if (tl > 0.2f) {
            val u = tang * (1f / tl)
            ghost + u * min(rayToBounds(ghost, u, t, r), 0.25f * L)
        } else null
        return Shot(tb, pk, path, ghost, tb.c - dir * r, after, cut, p, bank)
    }

    fun plan(t: Table, balls: List<Ball>, r: Float, group: Int, maxAlt: Int): List<Shot> {
        val cue = balls.firstOrNull { it.type == BallType.CUE } ?: return emptyList()
        val pks = pockets(t)
        val minD = 2f * r * 0.97f
        val shots = ArrayList<Shot>()
        val walls = listOf(
            Triple(true, t.left + r, t.leftReal), Triple(true, t.right - r, t.rightReal),
            Triple(false, t.top + r, t.topReal), Triple(false, t.bottom - r, t.bottomReal)
        )

        for (tb in balls) {
            if (tb.type == BallType.CUE) continue
            if (group == 1 && tb.type != BallType.SOLID) continue
            if (group == 2 && tb.type != BallType.STRIPE) continue
            val others = balls.filter { it !== tb && it !== cue }
            for (pk in pks) {
                val tp = pk.p - tb.c
                val dTP = tp.len()
                if (dTP < 1.5f * r) continue
                val dir = tp * (1f / dTP)
                if (dir.dot(pk.outward) < pk.minDot) continue
                val ghost = tb.c - dir * (2f * r)
                if (!insideCenters(ghost, t, r)) continue
                if (!clear(tb.c, pk.p, others, minD)) continue

                // Tacada direta
                val d1 = ghost - cue.c
                val len1 = d1.len()
                if (len1 > 0.5f * r) {
                    val a = d1 * (1f / len1)
                    val cosCut = a.dot(dir)
                    if (cosCut > 0.26f && clear(cue.c, ghost, others, minD)) {
                        shots += make(tb, pk, listOf(cue.c, ghost), ghost, a, dir, cosCut, len1, dTP, false, t, r)
                    }
                }
                // Tacadas com uma tabela (branca bate na borda antes)
                for ((vert, coord, real) in walls) {
                    if (!real) continue
                    val bp = bounce(cue.c, ghost, vert, coord, t, r) ?: continue
                    val a2 = (ghost - bp).norm()
                    val cosCut = a2.dot(dir)
                    if (cosCut < 0.34f) continue
                    val obs = balls.filter { it !== cue }
                    if (!clear(cue.c, bp, obs, minD) || !clear(bp, ghost, obs, 2f * r * 0.9f)) continue
                    val len = (bp - cue.c).len() + (ghost - bp).len()
                    shots += make(tb, pk, listOf(cue.c, bp, ghost), ghost, a2, dir, cosCut, len, dTP, true, t, r)
                }
            }
        }
        val sorted = shots.sortedByDescending { it.prob }
        val out = ArrayList<Shot>()
        for (s in sorted) {
            if (out.size >= 1 + maxAlt) break
            if (out.any { it.target === s.target && it.pocket === s.pocket }) continue
            out += s
        }
        return out
    }
}
