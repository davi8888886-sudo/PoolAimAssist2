package com.poolaimassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/**
 * Camada transparente onde as linhas são desenhadas.
 * O mapeamento usa a posição real da janela na tela (getLocationOnScreen) e o tamanho real da
 * captura (srcW/srcH), então as linhas não ficam deslocadas por barras de status/recorte (notch).
 * Toda linha é desenhada com um contorno escuro (halo) para contraste sobre qualquer feltro.
 */
class OverlayView(ctx: Context, private val prefs: Prefs) : View(ctx) {
    private var res: AnalysisResult? = null
    private var aim: AimResult? = null
    private var aimTarget: V? = null
    private var lines: List<String> = emptyList()
    private var debug = true
    private val d = ctx.resources.displayMetrics.density
    private val loc = IntArray(2)

    var onResized: (() -> Unit)? = null
    var aimMode = false
        set(v) {
            field = v
            if (v) { if (aimTarget == null) initAim() else recomputeAim() } else aim = null
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dash = DashPathEffect(floatArrayOf(14f * d, 10f * d), 0f)
    private val path = Path()
    private val pBox = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CC050B1A"); style = Paint.Style.FILL }
    private val pText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 13f * d }

    fun hasUsable(): Boolean {
        val r = res ?: return false
        return r.table != null && r.balls.any { it.type == BallType.CUE }
    }

    fun show(r: AnalysisResult) {
        res = r
        debug = prefs.showDebug
        lines = r.message?.let { listOf(it) } ?: emptyList()
        if (aimMode) { if (aimTarget == null) initAim() else recomputeAim() }
        invalidate()
    }

    fun showMessage(m: String) { lines = listOf(m); invalidate() }

    fun clear() { res = null; aim = null; aimTarget = null; lines = emptyList(); invalidate() }

    // ---------------- mira manual ----------------

    private fun initAim() {
        val r = res ?: return
        val t = r.table ?: return
        aimTarget = r.shots.firstOrNull()?.ghost ?: V((t.left + t.right) / 2f, (t.top + t.bottom) / 2f)
        recomputeAim()
    }

    private fun recomputeAim() {
        val r = res ?: return
        val t = r.table ?: return
        val cue = r.balls.firstOrNull { it.type == BallType.CUE } ?: return
        val tg = aimTarget ?: return
        aim = Aim.trace(cue, tg - cue.c, r.balls, t, r.pockets, r.ballR)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!aimMode) return false
        val r = res ?: return true
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            val kx = r.srcW.toFloat() / r.procW
            val ky = r.srcH.toFloat() / r.procH
            aimTarget = V(e.rawX / kx, e.rawY / ky)
            recomputeAim()
            invalidate()
        }
        return true
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (ow != 0 && oh != 0 && (w != ow || h != oh)) onResized?.invoke()
    }

    // ---------------- desenho ----------------

    private fun stroke(c: Canvas, color: Int, wDp: Float, alphaPct: Int, dashed: Boolean) {
        paint.pathEffect = if (dashed) dash else null
        paint.color = Color.BLACK
        paint.alpha = 150 * alphaPct / 100
        paint.strokeWidth = (wDp + 2f) * d
        c.drawPath(path, paint)
        paint.color = color
        paint.alpha = 255 * alphaPct / 100
        paint.strokeWidth = wDp * d
        c.drawPath(path, paint)
    }

    private fun polyline(c: Canvas, pts: List<V>, kx: Float, ky: Float, color: Int, wDp: Float, a: Int, dashed: Boolean = false) {
        if (pts.size < 2) return
        path.reset()
        pts.forEachIndexed { i, v -> if (i == 0) path.moveTo(v.x * kx, v.y * ky) else path.lineTo(v.x * kx, v.y * ky) }
        stroke(c, color, wDp, a, dashed)
    }

    private fun segment(c: Canvas, p: V, q: V, kx: Float, ky: Float, color: Int, wDp: Float, a: Int, dashed: Boolean = false) =
        polyline(c, listOf(p, q), kx, ky, color, wDp, a, dashed)

    private fun circle(c: Canvas, x: Float, y: Float, rad: Float, color: Int, wDp: Float, a: Int) {
        path.reset()
        path.addCircle(x, y, rad, Path.Direction.CW)
        stroke(c, color, wDp, a, false)
    }

    private fun dot(c: Canvas, x: Float, y: Float, color: Int) {
        fillP.color = Color.BLACK
        c.drawCircle(x, y, 6f * d, fillP)
        fillP.color = color
        c.drawCircle(x, y, 4f * d, fillP)
    }

    override fun onDraw(c: Canvas) {
        val r = res
        if (r != null && prefs.linesVisible) {
            getLocationOnScreen(loc)
            c.save()
            c.translate(-loc[0].toFloat(), -loc[1].toFloat())
            drawContent(c, r)
            c.restore()
        }
        drawMessage(c)
    }

    private fun drawContent(c: Canvas, r: AnalysisResult) {
        val kx = r.srcW.toFloat() / r.procW
        val ky = r.srcH.toFloat() / r.procH
        val w = prefs.lineWidth.toFloat()
        val a = prefs.lineAlpha
        val cCue = Prefs.color(prefs.colCue)
        val cTgt = Prefs.color(prefs.colTarget)
        val cAft = Prefs.color(prefs.colAfter)
        val cAim = Prefs.color(prefs.colAim)
        val rad = r.ballR * kx
        val orange = Color.parseColor("#FF6D00")

        if (debug) {
            r.table?.let { t ->
                path.reset()
                path.addRect(RectF(t.left * kx, t.top * ky, t.right * kx, t.bottom * ky), Path.Direction.CW)
                stroke(c, Color.WHITE, 1f, min(a, 45), false)
            }
            for (p in r.pockets) circle(c, p.p.x * kx, p.p.y * ky, rad * 1.6f, Color.parseColor("#FF5252"), 1.5f, min(a, 85))
            for (b in r.balls) {
                val col = if (b.type == BallType.CUE) Color.WHITE else Color.parseColor("#4FC3F7")
                circle(c, b.c.x * kx, b.c.y * ky, rad, col, 1.5f, min(a, 85))
            }
        }

        if (!aimMode) {
            // alternativas (mais discretas)
            for (s in r.shots.drop(1)) {
                polyline(c, s.cuePath, kx, ky, cCue, w * 0.6f, a * 45 / 100)
                segment(c, s.target.c, s.pocket.p, kx, ky, cTgt, w * 0.6f, a * 45 / 100)
            }
            // melhor jogada
            r.shots.firstOrNull()?.let { s ->
                polyline(c, s.cuePath, kx, ky, cCue, w, a)
                circle(c, s.ghost.x * kx, s.ghost.y * ky, rad, Color.WHITE, 2f, a)
                segment(c, s.target.c, s.pocket.p, kx, ky, cTgt, w, a)
                circle(c, s.pocket.p.x * kx, s.pocket.p.y * ky, rad * 1.6f, cCue, 2f, a)
                dot(c, s.contact.x * kx, s.contact.y * ky, orange)
                s.cueAfterEnd?.let { e -> segment(c, s.ghost, e, kx, ky, cAft, w * 0.8f, a, true) }
            }
        } else {
            val cue = r.balls.firstOrNull { it.type == BallType.CUE }
            if (cue != null) circle(c, cue.c.x * kx, cue.c.y * ky, rad * 1.25f, cAim, 2f, a)
            aim?.let { ar ->
                polyline(c, ar.cuePath, kx, ky, cAim, w + 0.5f, a)
                ar.ghost?.let { g -> circle(c, g.x * kx, g.y * ky, rad, Color.WHITE, 2f, a) }
                val tg = ar.target
                val te = ar.targetEnd
                if (tg != null && te != null) {
                    segment(c, tg.c, te, kx, ky, cTgt, w, a)
                    circle(c, tg.c.x * kx, tg.c.y * ky, rad * 1.25f, cTgt, 2f, a)
                    if (ar.targetPocketed) circle(c, te.x * kx, te.y * ky, rad * 1.6f, cCue, 2f, a)
                    else dot(c, te.x * kx, te.y * ky, orange)
                }
                ar.secondBall?.let { b -> circle(c, b.c.x * kx, b.c.y * ky, rad * 1.25f, orange, 2f, a) }
                val g = ar.ghost
                val ce = ar.cueAfterEnd
                if (g != null && ce != null) segment(c, g, ce, kx, ky, cAft, w * 0.8f, a, true)
            }
        }
    }

    private fun drawMessage(c: Canvas) {
        if (lines.isEmpty()) return
        val pad = 10f * d
        val lh = pText.textSize * 1.35f
        val w = lines.maxOf { pText.measureText(it) } + 2 * pad
        val x = (width - w) / 2f
        val y = 48f * d
        c.drawRoundRect(RectF(x, y, x + w, y + lines.size * lh + pad), 10f * d, 10f * d, pBox)
        lines.forEachIndexed { i, t -> c.drawText(t, x + pad, y + pad * 0.4f + (i + 1) * lh - 4f * d, pText) }
    }
}

/** Botão flutuante pequeno (abre/fecha o painel). */
class BubbleView(ctx: Context) : View(ctx) {
    var active = false
        set(v) { field = v; invalidate() }
    var busy = false
        set(v) { field = v; invalidate() }
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f * d; color = Color.parseColor("#00E676")
    }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.WHITE
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = width / 2f - 2f * d
        fill.color = when {
            busy -> Color.parseColor("#E6FFA000")
            active -> Color.parseColor("#E600A85A")
            else -> Color.parseColor("#E60A1F44")
        }
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, ring)
        c.drawCircle(cx, cy, r * 0.42f, cross)
        c.drawLine(cx, cy - r * 0.75f, cx, cy - r * 0.2f, cross)
        c.drawLine(cx, cy + r * 0.2f, cx, cy + r * 0.75f, cross)
        c.drawLine(cx - r * 0.75f, cy, cx - r * 0.2f, cy, cross)
        c.drawLine(cx + r * 0.2f, cy, cx + r * 0.75f, cy, cross)
    }
}
