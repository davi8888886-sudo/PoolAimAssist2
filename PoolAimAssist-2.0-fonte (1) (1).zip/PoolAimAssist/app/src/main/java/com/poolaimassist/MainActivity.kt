package com.poolaimassist

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val REQ_OVERLAY = 1
    private val REQ_NOTIF = 2
    private val REQ_PROJ = 3
    private val GAME_URL = "https://estrelagames.com/training/multi/"

    private var openChrome = false
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(56), dp(24), dp(32))
        }
        val title = TextView(this).apply {
            val s = SpannableString("POOL AIM\nASSIST")
            s.setSpan(ForegroundColorSpan(Color.WHITE), 0, 8, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            s.setSpan(ForegroundColorSpan(GREEN), 9, s.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = s; textSize = 38f; gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        col.addView(title)
        col.addView(uiText("Assistente visual de mira para sinuca · versão 2.0", 14f, Color.parseColor("#9FB3D1")).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(24))
        })
        status = uiText("", 13f, GREEN).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8)) }
        col.addView(status)

        col.addView(uiButton("Iniciar assistente", true) { startFlow(true) })
        col.addView(uiButton("Ativar botão flutuante", false) { startFlow(false) })
        col.addView(uiButton("Parar assistente", false) {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
            Toast.makeText(this, "Assistente encerrado", Toast.LENGTH_SHORT).show()
            status.postDelayed({ refresh() }, 400)
        })
        col.addView(uiButton("Configurações", false) { startActivity(Intent(this, SettingsActivity::class.java)) })
        col.addView(uiButton("Sobre o aplicativo", false) { about() })

        val sv = ScrollView(this)
        sv.background = darkBackground()
        sv.addView(col, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        status.text = if (CaptureService.running) "● Assistente ativo — use o botão flutuante" else "○ Assistente parado"
    }

    private fun startFlow(chrome: Boolean) {
        openChrome = chrome
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita \"Exibir sobre outros apps\" para o POOL AIM ASSIST", Toast.LENGTH_LONG).show()
            @Suppress("DEPRECATION")
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), REQ_OVERLAY
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            return
        }
        requestProjection()
    }

    private fun requestProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJ)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == REQ_NOTIF) requestProjection()   // notificação é opcional; segue o fluxo
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_OVERLAY -> if (Settings.canDrawOverlays(this)) startFlow(openChrome)
            else Toast.makeText(this, "Sem a permissão de sobreposição o botão não funciona.", Toast.LENGTH_LONG).show()
            REQ_PROJ -> if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_START)
                    .putExtra(CaptureService.EXTRA_CODE, resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
                startForegroundService(i)
                if (openChrome) openGame()
                status.postDelayed({ refresh() }, 600)
            } else Toast.makeText(this, "Captura de tela não autorizada.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openGame() {
        val uri = Uri.parse(GAME_URL)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.android.chrome"))
        } catch (e: ActivityNotFoundException) {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
        }
    }

    private fun about() {
        AlertDialog.Builder(this)
            .setTitle("POOL AIM ASSIST 2.0")
            .setMessage(
                "Lê a tela do celular (com sua autorização), detecta mesa, caçapas e bolas e desenha " +
                    "linhas de mira calculadas por geometria/física de colisão.\n\n" +
                    "• Toque no botão flutuante para abrir o painel: Analisar, Linhas, Auto, Mira, Calibrar, Fechar.\n" +
                    "• Calibrar: ajuste o retângulo sobre o feltro para a detecção ficar precisa.\n" +
                    "• Mira: arraste na tela para ver tabelas, colisão e desvio da branca (desligue para jogar).\n" +
                    "• Processamento 100% local, sem internet. Não acessa servidor do jogo, senhas ou contas.\n" +
                    "• Não faz tacadas por você: você executa a jogada.\n" +
                    "• Sem efeito/spin e sem atrito no cálculo: é uma estimativa, nunca uma garantia.\n\n" +
                    "Use com responsabilidade e respeite as regras do jogo."
            )
            .setPositiveButton("OK", null).show()
    }
}
