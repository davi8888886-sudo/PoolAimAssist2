package com.poolaimassist

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Mira manual: lança um raio a partir da bola branca na direção escolhida e calcula
 * (geometria exata, sem valores inventados):
 *  - até 2 tabelas (reflexão),
 *  - 1ª bola atingida (distância entre centros = 2r),
 *  - direção da bola atingida = linha de centros (bola fantasma -> alvo),
 *  - desvio da branca = componente tangente (bolas idênticas, sem atrito/efeito),
 *  - bola que a bola atingida encontra depois, ou caçapa.
 */
object Aim {

    /** Menor t >= 0 em que o centro de um raio o + t*u chega a minDist de alguma bola. */
    fun hitBall(o: V, u: V, balls: List<Ball>, minDist: Float): Pair<Float, Ball>? {
        var bestT = Float.MAX_VALUE
        var best: Ball? = null
        for (b in balls) {
            val m = o - b.c
            val bq = m.dot(u)
            val cq = m.dot(m) - minDist * minDist
            if (cq > 0f && bq > 0f) continue          // fora e se afastando
            val disc = bq * bq - cq
            if (disc < 0f) continue
            val t = -bq - sqrt(disc)
            if (t >= 0f && t < bestT) { bestT = t; best = b }
        }
        val bb = best ?: return null
        return Pair(bestT, bb)
    }

    /** Distância até a borda (limite do centro da bola); só considera bordas realmente visíveis. */
    fun wallDist(o: V, u: V, t: Table, r: Float): Float {
        var best = Float.MAX_VALUE
        if (u.x > 1e-4f && t.rightReal) best = min(best, (t.right - r - o.x) / u.x)
        else if (u.x < -1e-4f && t.leftReal) best = min(best, (t.left + r - o.x) / u.x)
        if (u.y > 1e-4f && t.bottomReal) best = min(best, (t.bottom - r - o.y) / u.y)
        else if (u.y < -1e-4f && t.topReal) best = min(best, (t.top + r - o.y) / u.y)
        return if (best == Float.MAX_VALUE) best else max(best, 0f)
    }

    fun trace(cue: Ball, dir: V, balls: List<Ball>, t: Table, pockets: List<Pocket>, r: Float): AimResult? {
        var u = dir.norm()
        if (u.len() < 0.5f) return null
        val others = balls.filter { it !== cue }
        val path = ArrayList<V>()
        var o = cue.c
        path.add(o)
        var remaining = t.longSide * 2.5f
        var bounces = 0
        var guard = 0
        while (guard < 6) {
            guard++
            val hb = hitBall(o, u, others, 2f * r)
            val tb = hb?.first ?: Float.MAX_VALUE
            val tw = wallDist(o, u, t, r)
            if (hb != null && tb <= tw && tb <= remaining) {
                return afterHit(path, o, u, tb, hb.second, others, t, pockets, r)
            }
            val seg = min(tw, remaining)
            val end = o + u * seg
            path.add(end)
            if (tw >= remaining || bounces >= 2) break
            remaining -= seg
            bounces++
            val e = 0.75f
            val hitX = (t.leftReal && end.x <= t.left + r + e) || (t.rightReal && end.x >= t.right - r - e)
            val hitY = (t.topReal && end.y <= t.top + r + e) || (t.bottomReal && end.y >= t.bottom - r - e)
            if (!hitX && !hitY) break
            u = V(if (hitX) -u.x else u.x, if (hitY) -u.y else u.y)
            o = end
        }
        return AimResult(path, null, null, null, false, null, null)
    }

    private fun afterHit(
        path: ArrayList<V>, o: V, u: V, tHit: Float, tgt: Ball, others: List<Ball>,
        t: Table, pockets: List<Pocket>, r: Float
    ): AimResult {
        val ghost = o + u * tHit
        path.add(ghost)
        val dir = (tgt.c - ghost).norm()
        val rest = others.filter { it !== tgt }

        // Trajetória da bola atingida: linha de centros
        val hb2 = hitBall(tgt.c, dir, rest, 2f * r)
        val tw2 = wallDist(tgt.c, dir, t, r)
        val cap = t.longSide * 1.5f
        val tEnd = min(min(hb2?.first ?: Float.MAX_VALUE, tw2), cap)
        var endP = tgt.c + dir * tEnd
        var second: Ball? = null
        if (hb2 != null && hb2.first <= tw2 && hb2.first <= cap) second = hb2.second
        var pocketed = false
        if (second == null) {
            for (pk in pockets) {
                if (dir.dot(pk.outward) < pk.minDot) continue
                if (Planner.segDist(pk.p, tgt.c, endP) < 1.8f * r) { endP = pk.p; pocketed = true; break }
            }
        }

        // Branca após o impacto: componente tangente da direção original
        val tang = u - dir * u.dot(dir)
        val tl = tang.len()
        var cueEnd: V? = null
        if (tl > 0.08f) {
            val v = tang * (1f / tl)
            val hb3 = hitBall(ghost, v, rest, 2f * r)
            val len = min(min(hb3?.first ?: Float.MAX_VALUE, wallDist(ghost, v, t, r)), t.longSide * 0.4f * tl)
            cueEnd = ghost + v * len
        }
        return AimResult(path, ghost, tgt, endP, pocketed, cueEnd, second)
    }
}
