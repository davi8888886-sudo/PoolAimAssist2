package com.poolaimassist

import kotlin.math.sqrt

data class V(val x: Float, val y: Float) {
    operator fun plus(o: V) = V(x + o.x, y + o.y)
    operator fun minus(o: V) = V(x - o.x, y - o.y)
    operator fun times(k: Float) = V(x * k, y * k)
    fun dot(o: V) = x * o.x + y * o.y
    fun len() = sqrt(x * x + y * y)
    fun norm(): V {
        val l = len()
        return if (l < 1e-6f) V(0f, 0f) else V(x / l, y / l)
    }
}

enum class BallType { CUE, SOLID, STRIPE, EIGHT }

data class Ball(val c: V, val r: Float, val type: BallType, val rgb: Int)

/** Área de feltro (centro de bola pode ir até borda - r). *Real = borda visível de verdade (não cortada pela tela). */
data class Table(
    val left: Float, val top: Float, val right: Float, val bottom: Float,
    val leftReal: Boolean, val topReal: Boolean, val rightReal: Boolean, val bottomReal: Boolean
) {
    val fullView get() = leftReal && topReal && rightReal && bottomReal
    val longSide get() = maxOf(right - left, bottom - top)
}

/** outward = direção que aponta para fora da mesa; minDot = alinhamento mínimo de entrada. */
data class Pocket(val p: V, val outward: V, val minDot: Float)

data class Shot(
    val target: Ball,
    val pocket: Pocket,
    val cuePath: List<V>,      // branca -> [tabela] -> bola fantasma
    val ghost: V,              // posição da branca no impacto
    val contact: V,            // ponto de contato na bola-alvo
    val cueAfterEnd: V?,       // fim da trajetória da branca após o impacto (sem efeito)
    val cutDeg: Float,
    val prob: Float,
    val bank: Boolean
)

/** procW/procH = tamanho da imagem analisada; srcW/srcH = tamanho real da tela capturada. */
data class AnalysisResult(
    val procW: Int, val procH: Int, val srcW: Int, val srcH: Int,
    val table: Table?, val pockets: List<Pocket>,
    val balls: List<Ball>, val ballR: Float,
    val shots: List<Shot>, val message: String?
)

/** Resultado da mira manual (raio da branca com tabelas, colisão e desvios). */
data class AimResult(
    val cuePath: List<V>,       // branca -> [tabelas] -> bola fantasma (ou fim da linha)
    val ghost: V?,              // posição da branca no impacto (null = não bateu em bola)
    val target: Ball?,          // bola atingida
    val targetEnd: V?,          // fim da trajetória da bola atingida
    val targetPocketed: Boolean,
    val cueAfterEnd: V?,        // fim da trajetória da branca após o impacto
    val secondBall: Ball?       // bola que a bola atingida vai bater (se houver)
)
