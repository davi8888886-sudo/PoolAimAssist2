package com.poolaimassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs

class CaptureService : Service() {

    companion object {
        const val ACTION_START = "com.poolaimassist.START"
        const val ACTION_STOP = "com.poolaimassist.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "pool_aim"
        private const val NOTIF_ID = 42
        @Volatile var running = false

        private val FLAGS_PASS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        private val FLAGS_TOUCH = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private val bgThread = HandlerThread("pool-capture").also { it.start() }
    private val bgHandler by lazy { Handler(bgThread.looper) }
    private val worker = Executors.newSingleThreadExecutor()

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var rw = 0
    private var rh = 0

    private var overlay: OverlayView? = null
    private var ovLp: WindowManager.LayoutParams? = null
    private var bubble: BubbleView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: PanelView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var calib: View? = null

    @Volatile private var busy = false
    private var panelOpen = false
    private var aimOn = false
    private var lastOk = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        prefs = Prefs(this)

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra(EXTRA_DATA)
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIF_ID, n)

        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mpm.getMediaProjection(code, data)
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
            projection = proj
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível iniciar a captura: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try { addOverlays() } catch (e: Exception) {
            Toast.makeText(this, "Permissão de sobreposição ausente.", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        running = true
        if (prefs.autoRefresh) main.postDelayed(autoRun, 1500)
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Pool Aim Assist", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("POOL AIM ASSIST 2.0 ativo")
            .setContentText("Toque no botão flutuante para abrir o painel")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Fechar", stopPi).build())
            .build()
    }

    private fun screenSize(): Point {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            val p = Point()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p)
            p
        }
    }

    private fun applyCutout(lp: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    // ------------------------------------------------------------------ janelas

    private fun addOverlays() {
        val ov = OverlayView(this, prefs)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, FLAGS_PASS, PixelFormat.TRANSLUCENT
        )
        applyCutout(lp)
        ov.onResized = {
            main.post {
                overlay?.clear()
                lastOk = false
                refreshBubble()
                if (aimOn) toggleAim()
                updateStatus("Tela girou. Toque em Analisar.")
            }
        }
        wm.addView(ov, lp)
        overlay = ov; ovLp = lp

        // painel (oculto até tocar na bolha)
        val pv = PanelView(this)
        pv.visibility = View.GONE
        val plp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        plp.gravity = Gravity.TOP or Gravity.START
        pv.bAnalyze.setOnClickListener { analyze(false) }
        pv.bLines.setOnClickListener {
            prefs.linesVisible = !prefs.linesVisible
            syncToggles(); refreshBubble(); overlay?.invalidate()
        }
        pv.bAuto.setOnClickListener { toggleAuto() }
        pv.bAim.setOnClickListener { toggleAim() }
        pv.bCalib.setOnClickListener { showCalibration() }
        pv.bClose.setOnClickListener { stopSelf() }
        wm.addView(pv, plp)
        panel = pv; panelLp = plp

        val d = resources.displayMetrics.density
        val b = BubbleView(this)
        val size = (50 * d).toInt()
        val blp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        blp.gravity = Gravity.TOP or Gravity.START
        blp.x = (12 * d).toInt(); blp.y = (90 * d).toInt()
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        var moved = false
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = blp.x; sy = blp.y; tx = e.rawX; ty = e.rawY; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        val sz = screenSize()
                        blp.x = (sx + dx).toInt().coerceIn(0, maxOf(0, sz.x - blp.width))
                        blp.y = (sy + dy).toInt().coerceIn(0, maxOf(0, sz.y - blp.height))
                        wm.updateViewLayout(v, blp)
                        if (panelOpen) placePanel()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        wm.addView(b, blp)
        bubble = b; bubbleLp = blp
        syncToggles()
    }

    private fun togglePanel() {
        val pv = panel ?: return
        panelOpen = !panelOpen
        pv.visibility = if (panelOpen) View.VISIBLE else View.GONE
        if (panelOpen) placePanel()
    }

    private fun placePanel() {
        val pv = panel ?: return
        val plp = panelLp ?: return
        val blp = bubbleLp ?: return
        pv.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val pw = pv.measuredWidth
        val ph = pv.measuredHeight
        val sz = screenSize()
        val gap = dp(6)
        var x = blp.x + blp.width + gap
        if (x + pw > sz.x) x = blp.x - pw - gap
        x = x.coerceIn(0, maxOf(0, sz.x - pw))
        val y = blp.y.coerceIn(0, maxOf(0, sz.y - ph))
        plp.x = x; plp.y = y
        try { wm.updateViewLayout(pv, plp) } catch (_: Exception) {}
    }

    private fun updateStatus(s: String) {
        val pv = panel ?: return
        pv.setStatus(s)
        if (panelOpen) main.post { placePanel() }
    }

    private fun syncToggles() {
        val pv = panel ?: return
        setPillOn(pv.bLines, prefs.linesVisible)
        setPillOn(pv.bAuto, prefs.autoRefresh)
        setPillOn(pv.bAim, aimOn)
    }

    private fun refreshBubble() { bubble?.active = lastOk && prefs.linesVisible }

    // ------------------------------------------------------------------ ações do painel

    private val autoRun = object : Runnable {
        override fun run() {
            if (!prefs.autoRefresh) return
            if (!busy && calib == null) analyze(true)
            main.postDelayed(this, prefs.autoMs.toLong())
        }
    }

    private fun toggleAuto() {
        prefs.autoRefresh = !prefs.autoRefresh
        main.removeCallbacks(autoRun)
        if (prefs.autoRefresh) {
            main.postDelayed(autoRun, 300)
            updateStatus("Atualização automática ligada (as linhas piscam rapidamente a cada captura).")
        } else updateStatus("Atualização automática desligada.")
        syncToggles()
    }

    private fun toggleAim() {
        val ov = overlay ?: return
        if (!aimOn && !ov.hasUsable()) {
            updateStatus("Analise a mesa primeiro (botão Analisar).")
            return
        }
        aimOn = !aimOn
        ov.aimMode = aimOn
        val lp = ovLp
        if (lp != null) {
            lp.flags = if (aimOn) FLAGS_TOUCH else FLAGS_PASS
            try { wm.updateViewLayout(ov, lp) } catch (_: Exception) {}
        }
        syncToggles()
        updateStatus(if (aimOn) "Mira manual: arraste na tela para apontar. Desligue para jogar." else "Mira manual desligada.")
    }

    // ------------------------------------------------------------------ calibração

    private fun showCalibration() {
        if (calib != null) return
        if (aimOn) toggleAim()
        val sz = screenSize()
        val cv = CalibView(this, sz.x, sz.y, prefs.getManualTable())
        val box = FrameLayout(this)
        box.addView(cv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val save = pill("Salvar mesa", 110, 44)
        val auto = pill("Usar auto", 90, 44)
        val cancel = pill("Cancelar", 90, 44)
        setPillOn(save, true)
        row.addView(save); row.addView(auto); row.addView(cancel)
        val rlp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        )
        rlp.bottomMargin = dp(24)
        box.addView(row, rlp)
        save.setOnClickListener {
            prefs.setManualTable(cv.fractions()); closeCalibration()
            updateStatus("Mesa calibrada."); analyze(false)
        }
        auto.setOnClickListener {
            prefs.setManualTable(null); closeCalibration()
            updateStatus("Calibração removida (detecção automática)."); analyze(false)
        }
        cancel.setOnClickListener { closeCalibration() }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, FLAGS_TOUCH, PixelFormat.TRANSLUCENT
        )
        applyCutout(lp)
        try {
            wm.addView(box, lp)
            calib = box
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível abrir a calibração.", Toast.LENGTH_LONG).show()
        }
    }

    private fun closeCalibration() {
        val v = calib ?: return
        calib = null
        try { wm.removeView(v) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ análise

    private fun setHidden(hidden: Boolean) {
        overlay?.visibility = if (hidden) View.INVISIBLE else View.VISIBLE
        bubble?.visibility = if (hidden) View.INVISIBLE else View.VISIBLE
        panel?.visibility = if (hidden) View.INVISIBLE else if (panelOpen) View.VISIBLE else View.GONE
    }

    private fun analyze(fromAuto: Boolean) {
        val bb = bubble ?: return
        if (busy || calib != null) return
        busy = true; bb.busy = true
        if (!fromAuto) updateStatus("Analisando…")
        setHidden(true)                       // as camadas não podem aparecer na captura
        worker.execute {
            var res: AnalysisResult? = null
            try {
                Thread.sleep(200)             // aguarda a remoção das camadas
                val bmp = try { captureBitmap() } catch (e: Exception) { null }
                if (bmp != null) {
                    res = try { Analyzer.run(bmp, prefs) } catch (t: Throwable) { null } finally { bmp.recycle() }
                }
            } catch (_: Throwable) {}
            main.post {
                busy = false; bb.busy = false
                setHidden(false)
                handleResult(res, fromAuto)
            }
        }
    }

    private fun handleResult(res: AnalysisResult?, fromAuto: Boolean) {
        val ov = overlay ?: return
        if (res == null) {
            lastOk = false; refreshBubble()
            if (!fromAuto) ov.showMessage("Falha ao capturar/analisar a tela. Toque em Analisar novamente.")
            updateStatus("Falha na captura.")
            return
        }
        val usable = res.table != null && res.balls.any { it.type == BallType.CUE }
        // no modo automático mantém a última leitura boa em vez de apagar as linhas
        if (usable || !fromAuto) ov.show(res)
        lastOk = usable || (fromAuto && lastOk)
        refreshBubble()
        val manual = prefs.getManualTable() != null
        val mesa = when {
            res.table == null -> "mesa ✗"
            manual -> "mesa ✓ (manual)"
            else -> "mesa ✓"
        }
        val branca = if (res.balls.any { it.type == BallType.CUE }) "✓" else "✗"
        val extra = res.message?.let { "\n$it" } ?: ""
        updateStatus("$mesa · bolas: ${res.balls.size} · branca $branca · jogadas: ${res.shots.size}$extra")
    }

    /** Captura 1 quadro: só liga a captura durante a análise (economiza bateria). */
    private fun captureBitmap(): Bitmap? {
        val size = screenSize()
        val w = size.x; val h = size.y
        val proj = projection ?: return null
        val dpi = resources.displayMetrics.densityDpi
        if (reader == null || w != rw || h != rh) {
            reader?.close()
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            rw = w; rh = h
            val cur = vd
            if (cur == null) {
                vd = proj.createVirtualDisplay(
                    "PoolAim", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, bgHandler
                )
            } else cur.resize(w, h, dpi)
        }
        val rd = reader ?: return null
        val display = vd ?: return null
        rd.acquireLatestImage()?.close()
        val latch = CountDownLatch(1)
        rd.setOnImageAvailableListener({ latch.countDown() }, bgHandler)
        display.setSurface(rd.surface)
        var bmp: Bitmap? = null
        try {
            if (latch.await(1500, TimeUnit.MILLISECONDS)) {
                Thread.sleep(50)
                val img = rd.acquireLatestImage()
                if (img != null) { bmp = imageToBitmap(img); img.close() }
            }
        } finally {
            rd.setOnImageAvailableListener(null, null)
            display.setSurface(null)
        }
        return bmp
    }

    private fun imageToBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val ps = plane.pixelStride
        val bw = plane.rowStride / ps
        val tmp = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        tmp.copyPixelsFromBuffer(plane.buffer)
        if (bw == img.width) return tmp
        val crop = Bitmap.createBitmap(tmp, 0, 0, img.width, img.height)
        tmp.recycle()
        return crop
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { calib?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { vd?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        bgThread.quitSafely()
        worker.shutdownNow()
        super.onDestroy()
    }
}
