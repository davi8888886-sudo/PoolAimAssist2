package com.poolaimassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

/**
 * Calibração da mesa: retângulo arrastável sobre a tela (coordenadas de tela).
 * Arraste os cantos para as bordas internas do feltro (onde ficam as caçapas) ou o centro para mover.
 */
class CalibView(ctx: Context, private val sw: Int, private val sh: Int, initial: FloatArray?) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val loc = IntArray(2)
    private var l: Float
    private var t: Float
    private var r: Float
    private var b: Float
    private var mode = -1
    private var lx = 0f
    private var ly = 0f

    private val dim = Paint().apply { color = Color.parseColor("#99000000"); style = Paint.Style.FILL }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676"); style = Paint.Style.STROKE; strokeWidth = 2f * d
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#00E676"); style = Paint.Style.FILL }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 14f * d; textAlign = Paint.Align.CENTER }

    init {
        val f = initial ?: floatArrayOf(0.08f, 0.22f, 0.92f, 0.88f)
        l = f[0] * sw; t = f[1] * sh; r = f[2] * sw; b = f[3] * sh
    }

    fun fractions() = floatArrayOf(l / sw, t / sh, r / sw, b / sh)

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        c.save()
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        c.drawRect(0f, 0f, sw.toFloat(), t, dim)
        c.drawRect(0f, b, sw.toFloat(), sh.toFloat(), dim)
        c.drawRect(0f, t, l, b, dim)
        c.drawRect(r, t, sw.toFloat(), b, dim)
        c.drawRect(l, t, r, b, edge)
        val hr = 14f * d
        c.drawCircle(l, t, hr, handle); c.drawCircle(r, t, hr, handle)
        c.drawCircle(l, b, hr, handle); c.drawCircle(r, b, hr, handle)
        c.drawText("Ajuste os cantos nas bordas internas do feltro", sw / 2f, 36f * d, txt)
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.rawX
        val y = e.rawY
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hit = 56f * d
                mode = when {
                    hypot(x - l, y - t) < hit -> 0
                    hypot(x - r, y - t) < hit -> 1
                    hypot(x - l, y - b) < hit -> 2
                    hypot(x - r, y - b) < hit -> 3
                    x in l..r && y in t..b -> 4
                    else -> -1
                }
                lx = x; ly = y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = x - lx
                val dy = y - ly
                lx = x; ly = y
                val minS = 120f
                when (mode) {
                    0 -> { l = (l + dx).coerceIn(0f, r - minS); t = (t + dy).coerceIn(0f, b - minS) }
                    1 -> { r = (r + dx).coerceIn(l + minS, sw.toFloat()); t = (t + dy).coerceIn(0f, b - minS) }
                    2 -> { l = (l + dx).coerceIn(0f, r - minS); b = (b + dy).coerceIn(t + minS, sh.toFloat()) }
                    3 -> { r = (r + dx).coerceIn(l + minS, sw.toFloat()); b = (b + dy).coerceIn(t + minS, sh.toFloat()) }
                    4 -> {
                        val w = r - l
                        val h = b - t
                        val nl = (l + dx).coerceIn(0f, sw - w)
                        val nt = (t + dy).coerceIn(0f, sh - h)
                        l = nl; t = nt; r = nl + w; b = nt + h
                    }
                }
                invalidate()
            }
        }
        return true
    }
}
