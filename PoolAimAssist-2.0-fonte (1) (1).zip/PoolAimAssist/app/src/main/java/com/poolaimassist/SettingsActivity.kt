package com.poolaimassist

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.Toast

class SettingsActivity : Activity() {
    private var radioBase = 1000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        val p = Prefs(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(40), dp(24), dp(32))
        }
        col.addView(uiText("Configurações", 28f, Color.WHITE, true))

        fun section(t: String) = col.addView(uiText(t, 15f, GREEN, true).apply { setPadding(0, dp(24), 0, dp(6)) })

        fun radios(options: List<String>, current: Int, onPick: (Int) -> Unit) {
            val base = radioBase
            radioBase += 100
            val g = RadioGroup(this)
            options.forEachIndexed { i, label ->
                g.addView(RadioButton(this).apply {
                    id = base + i; text = label; setTextColor(Color.WHITE)
                    buttonTintList = ColorStateList.valueOf(GREEN)
                })
            }
            g.check(base + current.coerceIn(0, options.size - 1))
            g.setOnCheckedChangeListener { _, id -> onPick(id - base) }
            col.addView(g)
        }

        fun slider(label: (Int) -> String, lo: Int, hi: Int, cur: Int, onChange: (Int) -> Unit) {
            val lbl = uiText(label(cur), 13f, Color.WHITE)
            val sb = SeekBar(this).apply {
                this.max = hi - lo
                progress = cur.coerceIn(lo, hi) - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                        onChange(v + lo); lbl.text = label(v + lo)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            col.addView(lbl); col.addView(sb)
        }

        fun swatches(label: String, get: () -> Int, set: (Int) -> Unit) {
            col.addView(uiText(label, 13f, Color.WHITE).apply { setPadding(0, dp(10), 0, dp(4)) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val views = ArrayList<View>()
            fun repaint() {
                views.forEachIndexed { i, v ->
                    val sel = i == get()
                    (v.background as GradientDrawable).setStroke(
                        dp(if (sel) 3 else 1), if (sel) Color.WHITE else Color.parseColor("#44FFFFFF")
                    )
                }
            }
            Prefs.PALETTE.forEachIndexed { i, colr ->
                val v = View(this)
                v.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(colr) }
                v.layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)).apply { rightMargin = dp(6) }
                v.setOnClickListener { set(i); repaint() }
                views.add(v); row.addView(v)
            }
            repaint()
            col.addView(row)
        }

        fun switchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
            col.addView(Switch(this).apply {
                this.text = text; setTextColor(Color.WHITE)
                isChecked = checked
                setOnCheckedChangeListener { _, c -> onChange(c) }
            })
        }

        section("Linhas de mira")
        switchRow("Mostrar linhas", p.linesVisible) { p.linesVisible = it }
        slider({ "Espessura: $it dp" }, 1, 8, p.lineWidth) { p.lineWidth = it }
        slider({ "Intensidade: $it%" }, 20, 100, p.lineAlpha) { p.lineAlpha = it }
        swatches("Linha da bola branca", { p.colCue }) { p.colCue = it }
        swatches("Linha da bola atingida", { p.colTarget }) { p.colTarget = it }
        swatches("Branca após o impacto (tracejada)", { p.colAfter }) { p.colAfter = it }
        swatches("Linha da mira manual", { p.colAim }) { p.colAim = it }

        section("Atualização automática")
        switchRow("Reanalisar a mesa sozinho (as linhas piscam brevemente a cada captura)", p.autoRefresh) { p.autoRefresh = it }
        val opts = listOf(1000, 1500, 2500)
        radios(listOf("A cada 1 s", "A cada 1,5 s", "A cada 2,5 s"), opts.indexOf(p.autoMs).coerceAtLeast(0)) { p.autoMs = opts[it] }
        col.addView(uiText("Se o assistente já estiver rodando, religue o botão Auto no painel para aplicar.", 12f, Color.parseColor("#9FB3D1")))

        section("Bolas do jogador")
        radios(listOf("Todas", "Lisas (1–7)", "Listradas (9–15)"), p.group) { p.group = it }

        section("Cor do feltro da mesa (modo automático)")
        radios(listOf("Automática", "Verde", "Azul"), p.feltMode) { p.feltMode = it }

        section("Jogadas alternativas exibidas")
        radios(listOf("Nenhuma", "1", "2", "3"), p.alternatives) { p.alternatives = it }

        section("Sensibilidade de detecção das bolas")
        slider({ "Limiar de cor: $it (menor = detecta mais)" }, 30, 100, p.sensitivity) { p.sensitivity = it }

        section("Calibração da mesa")
        col.addView(uiButton("Remover calibração manual", false) {
            p.setManualTable(null)
            Toast.makeText(this, "Calibração removida. Usando detecção automática.", Toast.LENGTH_SHORT).show()
        })
        col.addView(uiText("Para calibrar: abra o painel flutuante e toque em Calibrar.", 12f, Color.parseColor("#9FB3D1")))

        section("Depuração")
        switchRow("Mostrar mesa, caçapas e bolas detectadas", p.showDebug) { p.showDebug = it }
        col.addView(uiText("Deixe ligado para conferir se o app reconheceu a mesa e as bolas corretamente.", 12f, Color.parseColor("#9FB3D1")))

        val sv = ScrollView(this)
        sv.background = darkBackground()
        sv.addView(col, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(sv)
    }
}
