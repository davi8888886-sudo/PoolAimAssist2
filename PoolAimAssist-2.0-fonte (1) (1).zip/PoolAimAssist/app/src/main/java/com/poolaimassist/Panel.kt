package com.poolaimassist

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.LinearLayout
import android.widget.TextView

/** Painel flutuante compacto: status + 6 controles (todos com função real). */
class PanelView(ctx: Context) : LinearLayout(ctx) {
    val status = TextView(ctx)
    val bAnalyze = ctx.pill("Analisar", 66, 38)
    val bLines = ctx.pill("Linhas", 66, 38)
    val bAuto = ctx.pill("Auto", 66, 38)
    val bAim = ctx.pill("Mira", 66, 38)
    val bCalib = ctx.pill("Calibrar", 66, 38)
    val bClose = ctx.pill("Fechar", 66, 38)

    init {
        orientation = VERTICAL
        setPadding(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
        background = GradientDrawable().apply {
            cornerRadius = ctx.dp(16).toFloat()
            setColor(Color.parseColor("#EE050B1A"))
            setStroke(ctx.dp(1), Color.parseColor("#6600E676"))
        }
        status.textSize = 11f
        status.setTextColor(Color.WHITE)
        status.setPadding(ctx.dp(6), ctx.dp(2), ctx.dp(6), ctx.dp(4))
        status.text = "Toque em Analisar"
        status.layoutParams = LinearLayout.LayoutParams(ctx.dp(204), LinearLayout.LayoutParams.WRAP_CONTENT)
        addView(status)

        val r1 = LinearLayout(ctx)
        r1.addView(bAnalyze); r1.addView(bLines); r1.addView(bAuto)
        val r2 = LinearLayout(ctx)
        r2.addView(bAim); r2.addView(bCalib); r2.addView(bClose)
        addView(r1)
        addView(r2)
    }

    fun setStatus(s: String) { status.text = s }
}
