package com.poolaimassist

import kotlin.math.abs
import kotlin.math.min

/** Visão computacional 100% local, em Kotlin puro (sem OpenCV). */
object Vision {

    class Hsv(val h: FloatArray, val s: FloatArray, val v: FloatArray)
    class Felt(val table: Table, val rgb: IntArray)
    private class Peak(val x: Int, val y: Int, val d: Float)

    fun toHsv(px: IntArray): Hsv {
        val n = px.size
        val h = FloatArray(n); val s = FloatArray(n); val v = FloatArray(n)
        for (i in 0 until n) {
            val c = px[i]
            val r = ((c shr 16) and 255) / 255f
            val g = ((c shr 8) and 255) / 255f
            val b = (c and 255) / 255f
            val mx = maxOf(r, g, b)
            val mn = minOf(r, g, b)
            val d = mx - mn
            v[i] = mx
            s[i] = if (mx <= 0f) 0f else d / mx
            var hh = 0f
            if (d > 1e-6f) {
                hh = when (mx) {
                    r -> 60f * (((g - b) / d) % 6f)
                    g -> 60f * ((b - r) / d + 2f)
                    else -> 60f * ((r - g) / d + 4f)
                }
                if (hh < 0f) hh += 360f
            }
            h[i] = hh
        }
        return Hsv(h, s, v)
    }

    private fun hueDist(a: Float, b: Float): Float {
        val d = abs(a - b)
        return min(d, 360f - d)
    }

    /** Localiza o feltro: cor saturada dominante cujo retângulo tenha proporção de mesa. */
    fun findTable(w: Int, h: Int, px: IntArray, hsv: Hsv, feltMode: Int): Felt? {
        val n = w * h
        val centers = ArrayList<Float>()
        when (feltMode) {
            1 -> centers.add(125f)
            2 -> centers.add(215f)
            else -> {
                val hist = IntArray(36)
                var tot = 0
                for (i in 0 until n) {
                    if (hsv.s[i] > 0.3f && hsv.v[i] > 0.2f) {
                        hist[(hsv.h[i] / 10f).toInt().coerceIn(0, 35)]++
                        tot++
                    }
                }
                if (tot < n / 50) return null
                val sm = IntArray(36) { hist[(it + 35) % 36] + hist[it] + hist[(it + 1) % 36] }
                val order = (0 until 36).sortedByDescending { sm[it] }
                val chosen = ArrayList<Int>()
                for (b in order) {
                    if (chosen.size >= 3 || sm[b] < n / 60) break
                    if (chosen.none { c -> min(abs(c - b), 36 - abs(c - b)) < 3 }) chosen.add(b)
                }
                for (b in chosen) centers.add(b * 10f + 5f)
            }
        }
        val tol = if (feltMode == 0) 24f else 32f
        var best: Felt? = null
        var bestScore = 0f
        val margin = 0.012f * maxOf(w, h)

        for (hc in centers) {
            val mask = BooleanArray(n)
            val rowCnt = IntArray(h)
            val colCnt = IntArray(w)
            for (y in 0 until h) for (x in 0 until w) {
                val i = y * w + x
                if (hsv.s[i] > 0.25f && hsv.v[i] > 0.15f && hueDist(hsv.h[i], hc) <= tol) {
                    mask[i] = true; rowCnt[y]++; colCnt[x]++
                }
            }
            val maxRow = rowCnt.max()
            val maxCol = colCnt.max()
            if (maxRow < w * 0.25f || maxCol < h * 0.2f) continue
            val tr = maxRow * 0.35f
            val tc = maxCol * 0.35f
            var top = 0; while (top < h && rowCnt[top] < tr) top++
            var bottom = h - 1; while (bottom >= 0 && rowCnt[bottom] < tr) bottom--
            var left = 0; while (left < w && colCnt[left] < tc) left++
            var right = w - 1; while (right >= 0 && colCnt[right] < tc) right--
            if (right - left < w * 0.25f || bottom - top < h * 0.2f) continue

            var cnt = 0
            var sr = 0L; var sg = 0L; var sb = 0L
            for (y in top..bottom) for (x in left..right) {
                val i = y * w + x
                if (mask[i]) {
                    cnt++
                    sr += (px[i] shr 16) and 255
                    sg += (px[i] shr 8) and 255
                    sb += px[i] and 255
                }
            }
            if (cnt == 0) continue
            val bw = right - left + 1
            val bh = bottom - top + 1
            val fill = cnt.toFloat() / (bw * bh)
            val ar = maxOf(bw, bh).toFloat() / minOf(bw, bh)
            val arScore = if (ar in 1.6f..2.5f) 1f else 0.6f
            val score = cnt * arScore * (if (fill > 0.5f) 1f else 0.7f)
            if (score > bestScore) {
                bestScore = score
                val t = Table(
                    left.toFloat(), top.toFloat(), (right + 1).toFloat(), (bottom + 1).toFloat(),
                    left > margin, top > margin, right < w - 1 - margin, bottom < h - 1 - margin
                )
                best = Felt(t, intArrayOf((sr / cnt).toInt(), (sg / cnt).toInt(), (sb / cnt).toInt()))
            }
        }
        return best
    }

    /**
     * Mesa definida pelo usuário (frações da tela). A cor do feltro é a cor dominante
     * dentro do retângulo (moda em bins de 4 bits, refinada pela média dos pixels próximos).
     */
    fun manualFelt(w: Int, h: Int, px: IntArray, f: FloatArray): Felt {
        val l = (f[0] * w).coerceIn(0f, w - 2f)
        val t = (f[1] * h).coerceIn(0f, h - 2f)
        val r = (f[2] * w).coerceIn(l + 1f, w.toFloat())
        val b = (f[3] * h).coerceIn(t + 1f, h.toFloat())
        val table = Table(l, t, r, b, true, true, true, true)
        val mx = ((r - l) * 0.1f).toInt()
        val my = ((b - t) * 0.1f).toInt()
        val x0 = l.toInt() + mx
        val x1 = minOf(r.toInt() - mx, w)
        val y0 = t.toInt() + my
        val y1 = minOf(b.toInt() - my, h)

        val cnt = IntArray(4096)
        val sr = LongArray(4096)
        val sg = LongArray(4096)
        val sb = LongArray(4096)
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val c = px[y * w + x]
                val rr = (c shr 16) and 255
                val gg = (c shr 8) and 255
                val bb = c and 255
                val bin = ((rr shr 4) shl 8) or ((gg shr 4) shl 4) or (bb shr 4)
                cnt[bin]++; sr[bin] += rr.toLong(); sg[bin] += gg.toLong(); sb[bin] += bb.toLong()
                x += 2
            }
            y += 2
        }
        var best = 0
        for (i in 1 until 4096) if (cnt[i] > cnt[best]) best = i
        if (cnt[best] == 0) return Felt(table, intArrayOf(0, 100, 60))
        val m0r = (sr[best] / cnt[best]).toInt()
        val m0g = (sg[best] / cnt[best]).toInt()
        val m0b = (sb[best] / cnt[best]).toInt()

        var n2 = 0
        var r2 = 0L; var g2 = 0L; var b2 = 0L
        y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val c = px[y * w + x]
                val rr = (c shr 16) and 255
                val gg = (c shr 8) and 255
                val bb = c and 255
                val dr = rr - m0r; val dg = gg - m0g; val db = bb - m0b
                if (dr * dr + dg * dg + db * db <= 45 * 45) { n2++; r2 += rr; g2 += gg; b2 += bb }
                x += 2
            }
            y += 2
        }
        if (n2 == 0) return Felt(table, intArrayOf(m0r, m0g, m0b))
        return Felt(table, intArrayOf((r2 / n2).toInt(), (g2 / n2).toInt(), (b2 / n2).toInt()))
    }

    /**
     * Detecta bolas: pixels "não-feltro" -> transformada de distância -> máximos locais
     * (cada bola vira um pico, mesmo encostadas). Raio estimado pela moda dos picos.
     * Retorna (bolas, raio) ou null.
     */
    fun detectBalls(
        w: Int, h: Int, px: IntArray, hsv: Hsv, felt: Felt, sens: Int, pockets: List<Pocket>
    ): Pair<List<Ball>, Float>? {
        val t = felt.table
        val x0 = t.left.toInt().coerceIn(0, w - 1)
        val x1 = (t.right.toInt() - 1).coerceIn(0, w - 1)
        val y0 = t.top.toInt().coerceIn(0, h - 1)
        val y1 = (t.bottom.toInt() - 1).coerceIn(0, h - 1)
        if (x1 - x0 < 10 || y1 - y0 < 10) return null

        val n = w * h
        val thr2 = sens * sens
        val fr = felt.rgb[0]; val fg = felt.rgb[1]; val fb = felt.rgb[2]
        val mask = BooleanArray(n)
        for (y in y0..y1) for (x in x0..x1) {
            val i = y * w + x
            val c = px[i]
            val dr = ((c shr 16) and 255) - fr
            val dg = ((c shr 8) and 255) - fg
            val db = (c and 255) - fb
            if (dr * dr + dg * dg + db * db > thr2) mask[i] = true
        }

        // Transformada de distância (chamfer 1 / 1.414)
        val INF = 1e6f
        val dt = FloatArray(n)
        for (y in y0..y1) for (x in x0..x1) {
            val i = y * w + x
            dt[i] = when {
                !mask[i] -> 0f
                x == x0 || x == x1 || y == y0 || y == y1 -> 1f
                else -> INF
            }
        }
        for (y in y0..y1) for (x in x0..x1) {
            val i = y * w + x
            var d = dt[i]
            if (d == 0f) continue
            if (x > x0) d = min(d, dt[i - 1] + 1f)
            if (y > y0) {
                d = min(d, dt[i - w] + 1f)
                if (x > x0) d = min(d, dt[i - w - 1] + 1.414f)
                if (x < x1) d = min(d, dt[i - w + 1] + 1.414f)
            }
            dt[i] = d
        }
        for (y in y1 downTo y0) for (x in x1 downTo x0) {
            val i = y * w + x
            var d = dt[i]
            if (d == 0f) continue
            if (x < x1) d = min(d, dt[i + 1] + 1f)
            if (y < y1) {
                d = min(d, dt[i + w] + 1f)
                if (x < x1) d = min(d, dt[i + w + 1] + 1.414f)
                if (x > x0) d = min(d, dt[i + w - 1] + 1.414f)
            }
            dt[i] = d
        }

        // Máximos locais
        val cand = ArrayList<Int>()
        for (y in y0 + 1 until y1) for (x in x0 + 1 until x1) {
            val i = y * w + x
            val d = dt[i]
            if (d < 3f) continue
            if (dt[i - 1] <= d && dt[i + 1] <= d && dt[i - w] <= d && dt[i + w] <= d &&
                dt[i - w - 1] <= d && dt[i - w + 1] <= d && dt[i + w - 1] <= d && dt[i + w + 1] <= d
            ) cand.add(i)
        }
        cand.sortByDescending { dt[it] }

        // Supressão de não-máximos
        val peaks = ArrayList<Peak>()
        for (i in cand) {
            val x = i % w
            val y = i / w
            val d = dt[i]
            var ok = true
            for (p in peaks) {
                val dx = (p.x - x).toFloat()
                val dy = (p.y - y).toFloat()
                val rad = 0.9f * p.d
                if (dx * dx + dy * dy < rad * rad) { ok = false; break }
            }
            if (ok) peaks.add(Peak(x, y, d))
            if (peaks.size > 400) break
        }

        // Estimativa do raio (moda)
        val prior = if (t.fullView) 0.01125f * t.longSide else 0f
        val lo = if (prior > 0f) prior * 0.55f else 3f
        val hi = if (prior > 0f) prior * 1.8f else minOf(w, h) * 0.08f
        val vals = peaks.filter { it.d in lo..hi }.map { it.d }
        if (vals.isEmpty()) return null
        val counts = HashMap<Int, Int>()
        for (v in vals) { val k = (v * 2f).toInt(); counts[k] = (counts[k] ?: 0) + 1 }
        var bestK = 0; var bestC = -1
        for ((k, _) in counts) {
            val c = (counts[k - 1] ?: 0) + (counts[k] ?: 0) + (counts[k + 1] ?: 0)
            if (c > bestC) { bestC = c; bestK = k }
        }
        val near = vals.filter { it >= (bestK - 1) / 2f && it < (bestK + 2) / 2f }
        val r = (near.average().toFloat() + 0.5f)

        // Filtra bolas
        val balls = ArrayList<Peak>()
        for (p in peaks) {
            if (p.d < 0.72f * r || p.d > 1.4f * r) continue
            val c = V(p.x.toFloat(), p.y.toFloat())
            if (pockets.any { (it.p - c).len() < 2.0f * r }) continue
            // disco preenchido?
            var tot = 0; var fill = 0
            val rr = (0.8f * r).toInt()
            for (dy in -rr..rr) for (dx in -rr..rr) {
                if (dx * dx + dy * dy > rr * rr) continue
                val xx = p.x + dx; val yy = p.y + dy
                if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue
                tot++
                if (mask[yy * w + xx]) fill++
            }
            if (tot == 0 || fill < 0.85f * tot) continue
            balls.add(p)
        }
        if (balls.isEmpty()) return null

        // Classificação por cor
        class Info(val p: Peak, val white: Float, val dark: Float, val rgb: Int)
        val infos = balls.map { p ->
            val rr = (0.6f * r).toInt().coerceAtLeast(1)
            var tot = 0; var wh = 0; var dk = 0
            var sr = 0L; var sg = 0L; var sb = 0L
            for (dy in -rr..rr) for (dx in -rr..rr) {
                if (dx * dx + dy * dy > rr * rr) continue
                val xx = p.x + dx; val yy = p.y + dy
                if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue
                val i = yy * w + xx
                tot++
                if (hsv.s[i] < 0.25f && hsv.v[i] > 0.72f) wh++
                if (hsv.v[i] < 0.30f) dk++
                sr += (px[i] shr 16) and 255; sg += (px[i] shr 8) and 255; sb += px[i] and 255
            }
            val t0 = maxOf(tot, 1)
            Info(p, wh.toFloat() / t0, dk.toFloat() / t0,
                (0xFF shl 24) or ((sr / t0).toInt() shl 16) or ((sg / t0).toInt() shl 8) or (sb / t0).toInt())
        }
        val cueInfo = infos.maxByOrNull { it.white }?.takeIf { it.white >= 0.6f }
        val out = infos.map { inf ->
            val type = when {
                inf === cueInfo -> BallType.CUE
                inf.dark > 0.55f -> BallType.EIGHT
                inf.white >= 0.2f -> BallType.STRIPE
                else -> BallType.SOLID
            }
            Ball(V(inf.p.x.toFloat(), inf.p.y.toFloat()), r, type, inf.rgb)
        }
        return Pair(out, r)
    }
}
