package com.poolaimassist

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

val NAVY = Color.parseColor("#0A1F44")
val GREEN = Color.parseColor("#00E676")

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

fun darkBackground(): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.BLACK, NAVY))

fun Context.uiButton(text: String, primary: Boolean, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = text
    b.isAllCaps = false
    b.textSize = 16f
    b.stateListAnimator = null
    b.setTextColor(if (primary) Color.BLACK else Color.WHITE)
    b.background = GradientDrawable().apply {
        cornerRadius = dp(28).toFloat()
        if (primary) setColor(GREEN) else { setColor(Color.parseColor("#14305F")); setStroke(dp(1), GREEN) }
    }
    b.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { topMargin = dp(12) }
    b.setOnClickListener { onClick() }
    return b
}

fun Context.uiText(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text; t.textSize = size; t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
    t.gravity = Gravity.START
    return t
}

/** Botão compacto (pílula) usado no painel flutuante e na calibração. */
fun Context.pill(text: String, widthDp: Int, heightDp: Int): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = 11f
    t.gravity = Gravity.CENTER
    t.isClickable = true
    t.layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(heightDp)).apply {
        setMargins(dp(2), dp(2), dp(2), dp(2))
    }
    setPillOn(t, false)
    return t
}

fun Context.setPillOn(t: TextView, on: Boolean) {
    t.setTextColor(if (on) Color.BLACK else Color.WHITE)
    t.background = GradientDrawable().apply {
        cornerRadius = dp(18).toFloat()
        if (on) setColor(GREEN) else { setColor(Color.parseColor("#14305F")); setStroke(dp(1), GREEN) }
    }
}
