package com.poolaimassist

import android.content.Context
import android.graphics.Color

class Prefs(ctx: Context) {
    companion object {
        val PALETTE = intArrayOf(
            Color.parseColor("#00E676"), Color.parseColor("#FFD54F"), Color.parseColor("#4FC3F7"),
            Color.parseColor("#FFFFFF"), Color.parseColor("#FF6D00"), Color.parseColor("#FF4081"),
            Color.parseColor("#FF5252"), Color.parseColor("#B388FF")
        )
        fun color(i: Int) = PALETTE[i.coerceIn(0, PALETTE.size - 1)]
    }

    private val sp = ctx.getSharedPreferences("pool_aim", Context.MODE_PRIVATE)

    var showDebug: Boolean
        get() = sp.getBoolean("debug", true)
        set(v) { sp.edit().putBoolean("debug", v).apply() }
    /** 0 = todas, 1 = lisas, 2 = listradas */
    var group: Int
        get() = sp.getInt("group", 0)
        set(v) { sp.edit().putInt("group", v).apply() }
    /** 0 = auto, 1 = verde, 2 = azul */
    var feltMode: Int
        get() = sp.getInt("felt", 0)
        set(v) { sp.edit().putInt("felt", v).apply() }
    var sensitivity: Int
        get() = sp.getInt("sens", 60)
        set(v) { sp.edit().putInt("sens", v).apply() }
    var alternatives: Int
        get() = sp.getInt("alts", 2)
        set(v) { sp.edit().putInt("alts", v).apply() }

    // ---- 2.0: aparência das linhas ----
    var linesVisible: Boolean
        get() = sp.getBoolean("lines", true)
        set(v) { sp.edit().putBoolean("lines", v).apply() }
    /** espessura em dp (1..8) */
    var lineWidth: Int
        get() = sp.getInt("lw", 3)
        set(v) { sp.edit().putInt("lw", v).apply() }
    /** intensidade / opacidade em % (20..100) */
    var lineAlpha: Int
        get() = sp.getInt("la", 100)
        set(v) { sp.edit().putInt("la", v).apply() }
    var colCue: Int
        get() = sp.getInt("c_cue", 0)
        set(v) { sp.edit().putInt("c_cue", v).apply() }
    var colTarget: Int
        get() = sp.getInt("c_tgt", 1)
        set(v) { sp.edit().putInt("c_tgt", v).apply() }
    var colAfter: Int
        get() = sp.getInt("c_aft", 2)
        set(v) { sp.edit().putInt("c_aft", v).apply() }
    var colAim: Int
        get() = sp.getInt("c_aim", 5)
        set(v) { sp.edit().putInt("c_aim", v).apply() }

    // ---- 2.0: atualização automática ----
    var autoRefresh: Boolean
        get() = sp.getBoolean("auto", false)
        set(v) { sp.edit().putBoolean("auto", v).apply() }
    var autoMs: Int
        get() = sp.getInt("auto_ms", 1500)
        set(v) { sp.edit().putInt("auto_ms", v).apply() }

    // ---- 2.0: calibração manual da mesa (frações da tela: esquerda, topo, direita, base) ----
    fun getManualTable(): FloatArray? {
        if (!sp.getBoolean("mt_on", false)) return null
        return floatArrayOf(sp.getFloat("mt_l", 0f), sp.getFloat("mt_t", 0f), sp.getFloat("mt_r", 1f), sp.getFloat("mt_b", 1f))
    }

    fun setManualTable(a: FloatArray?) {
        val e = sp.edit()
        if (a == null) {
            e.putBoolean("mt_on", false)
        } else {
            e.putBoolean("mt_on", true)
            e.putFloat("mt_l", a[0]); e.putFloat("mt_t", a[1]); e.putFloat("mt_r", a[2]); e.putFloat("mt_b", a[3])
        }
        e.apply()
    }
}
