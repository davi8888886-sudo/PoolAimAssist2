package com.poolaimassist

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Imagem sintética: feltro verde 800x400 com 3 bolas (branca, vermelha, azul). */
class VisionTest {
    private val w = 800
    private val h = 400

    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    private fun image(): IntArray {
        val px = IntArray(w * h) { rgb(20, 120, 60) }
        fun disc(cx: Int, cy: Int, rad: Int, c: Int) {
            for (y in cy - rad..cy + rad) for (x in cx - rad..cx + rad)
                if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= rad * rad) px[y * w + x] = c
        }
        disc(200, 200, 9, rgb(250, 250, 250))
        disc(450, 200, 9, rgb(200, 40, 40))
        disc(300, 120, 9, rgb(30, 60, 200))
        return px
    }

    @Test fun detectsThreeBallsAndTheCue() {
        val px = image()
        val hsv = Vision.toHsv(px)
        val felt = Vision.manualFelt(w, h, px, floatArrayOf(0.02f, 0.02f, 0.98f, 0.98f))
        val pockets = Planner.pockets(felt.table)
        val det = Vision.detectBalls(w, h, px, hsv, felt, 60, pockets)
        assertNotNull(det)
        val (balls, r) = det!!
        assertEquals(3, balls.size)
        assertEquals(1, balls.count { it.type == BallType.CUE })
        assertTrue(r in 8f..11f)
        val cue = balls.first { it.type == BallType.CUE }
        assertEquals(200f, cue.c.x, 2.5f)
        assertEquals(200f, cue.c.y, 2.5f)
    }
}
