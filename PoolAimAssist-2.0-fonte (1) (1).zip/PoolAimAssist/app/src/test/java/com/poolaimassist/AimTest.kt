package com.poolaimassist

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class AimTest {
    private val r = 10f
    private val table = Table(0f, 0f, 800f, 400f, true, true, true, true)
    private val pockets = Planner.pockets(table)
    private fun ball(x: Float, y: Float, t: BallType = BallType.SOLID) = Ball(V(x, y), r, t, 0)

    @Test fun straightHit() {
        val cue = ball(100f, 200f, BallType.CUE)
        val tgt = ball(300f, 200f)
        val a = Aim.trace(cue, V(1f, 0f), listOf(cue, tgt), table, pockets, r)
        assertNotNull(a)
        assertEquals(280f, a!!.ghost!!.x, 0.01f)
        assertEquals(200f, a.ghost!!.y, 0.01f)
        assertTrue(a.target === tgt)
        assertTrue(a.targetEnd!!.x > 300f)
        assertNull(a.cueAfterEnd)          // batida frontal: a branca para
    }

    @Test fun cutShotGeometry() {
        val cue = ball(100f, 200f, BallType.CUE)
        val tgt = ball(300f, 210f)
        val a = Aim.trace(cue, V(1f, 0f), listOf(cue, tgt), table, pockets, r)!!
        val g = a.ghost!!
        assertEquals(2f * r, (tgt.c - g).len(), 0.01f)           // centros a 2r no impacto
        val dir = (tgt.c - g).norm()
        val after = a.cueAfterEnd!! - g
        assertTrue(abs(after.dot(dir)) < 0.01f * after.len())      // branca sai a 90° da linha de centros
    }

    @Test fun wallBounce() {
        val cue = ball(400f, 200f, BallType.CUE)
        val a = Aim.trace(cue, V(1f, 1f), listOf(cue), table, pockets, r)!!
        assertEquals(590f, a.cuePath[1].x, 0.05f)                  // bate na borda inferior (y = 400 - r)
        assertEquals(390f, a.cuePath[1].y, 0.05f)
        assertTrue(a.cuePath.size >= 3)
        assertTrue(a.cuePath[2].y < a.cuePath[1].y)                // depois da tabela sobe
        assertNull(a.ghost)
    }

    @Test fun missesBallOffLine() {
        val cue = ball(100f, 200f, BallType.CUE)
        val far = ball(300f, 260f)
        val a = Aim.trace(cue, V(1f, 0f), listOf(cue, far), table, pockets, r)!!
        assertNull(a.ghost)
    }
}
