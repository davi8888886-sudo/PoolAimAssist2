package com.poolaimassist

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlannerTest {
    @Test fun findsDirectShotToCorner() {
        val r = 9f
        val table = Table(0f, 0f, 800f, 400f, true, true, true, true)
        val cue = Ball(V(500f, 200f), r, BallType.CUE, 0)
        val tgt = Ball(V(720f, 60f), r, BallType.SOLID, 0)
        val shots = Planner.plan(table, listOf(cue, tgt), r, 0, 2)
        assertTrue(shots.isNotEmpty())
        val s = shots.first()
        assertTrue(s.target === tgt)
        assertFalse(s.bank)
        assertEquals(705.6f, s.ghost.x, 0.1f)
        assertEquals(70.8f, s.ghost.y, 0.1f)
    }

    @Test fun blockedShotIsRejected() {
        val r = 9f
        val table = Table(0f, 0f, 800f, 400f, true, true, true, true)
        val cue = Ball(V(500f, 200f), r, BallType.CUE, 0)
        val tgt = Ball(V(720f, 60f), r, BallType.SOLID, 0)
        val blocker = Ball(V(760f, 30f), r, BallType.SOLID, 0)   // sobre a linha alvo -> caçapa
        val shots = Planner.plan(table, listOf(cue, tgt, blocker), r, 0, 2)
        assertTrue(shots.none { it.target === tgt && it.pocket.p == V(800f, 0f) })
    }
}
