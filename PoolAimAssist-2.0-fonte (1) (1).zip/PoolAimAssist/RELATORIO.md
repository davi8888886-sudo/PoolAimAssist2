# Relatório — POOL AIM ASSIST 2.0

## Diagnóstico do projeto enviado (1.0)
- Código-fonte completo e legível no ZIP (Kotlin, sem dependências). Nada foi "recuperado" do APK; o APK enviado não foi decompilado.
- Só existia análise de **um quadro por toque**; não havia modo contínuo.
- Linhas dependiam 100% da detecção automática do feltro. Se falhasse, só aparecia uma mensagem e nenhuma linha.
- O desenho usava `largura da view / largura da imagem`; barras do sistema/recorte de tela podiam deslocar as linhas.
- Linhas sem contorno (pouco contraste), cores fixas, sem controle de espessura/intensidade.
- **Não existe tacada automática no projeto** (nenhum serviço de acessibilidade/gesto). Ela **não foi implementada** de propósito:
  automatizar a jogada dentro de um jogo é automação de jogo e costuma violar os termos de uso.

## O que mudou na 2.0
| Item | Mudança |
|---|---|
| Alinhamento | Linhas mapeadas por `getLocationOnScreen` + tamanho real da captura (sem deslocamento por barras/notch) |
| Visibilidade | Contorno escuro em todas as linhas; cores, espessura e intensidade configuráveis |
| Mesa | Calibração manual (retângulo arrastável); cor do feltro obtida da própria área calibrada |
| Mira manual | `Aim.kt`: raio com até 2 tabelas, 1ª colisão, direção da bola atingida, desvio da branca, 2ª bola/caçapa |
| Painel | Painel flutuante compacto: Analisar, Linhas, Auto, Mira, Calibrar, Fechar + status (mesa/bolas/branca/jogadas) |
| Auto | Reanálise periódica; mantém a última leitura boa se uma captura falhar |
| Estabilidade | Rotação de tela limpa as linhas; limpeza completa de janelas ao fechar |
| Testes | Testes unitários (`app/src/test`) para mira, planner e visão em imagem sintética |

## Verificação realizada nesta entrega (honesta)
- ✔ Valores esperados dos testes de geometria (colisão reta, corte, tabela, bola fora da linha, bola fantasma do planner)
  conferidos com um espelho em Python das mesmas fórmulas.
- ✘ **Não compilado** (o ambiente de geração não tem Android SDK/Gradle/internet).
- ✘ **Não executado em aparelho** (Galaxy M23) — linhas na tela, detecção em capturas reais do jogo, painel, calibração,
  Mira manual e uso de memória/estabilidade **ainda não foram testados**.
- ✘ Testes unitários escritos mas **ainda não rodados**; o workflow os executa (`gradle testDebugUnitTest`).

## Checklist para você validar no celular
1. Linhas aparecem após *Analisar*? 2. Alinhadas com as bolas? 3. *Calibrar* melhora a detecção?
4. *Mira* mostra tabela/colisão/desvio? 5. *Linhas* oculta/mostra? 6. *Auto* atualiza sem travar? 7. Girar a tela não fecha o app?
Se algo falhar, mande o texto do erro (ou o log do Actions) e uma captura de tela do jogo.
